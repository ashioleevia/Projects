import os
os.system("start /B start cmd.exe @cmd /c py test.py")
