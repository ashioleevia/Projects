import datetime
from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Staff(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    staff_name=models.CharField(max_length=50,null=True)
    staff_id=models.IntegerField(null=True)
    department=models.CharField(max_length=50,null=True)
    password=models.CharField(max_length=50,null=True)

class student(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    student_name=models.CharField(max_length=50,null=True)
    student_id=models.IntegerField(null=True)
    student_department=models.CharField(max_length=50,null=True)
    student_password=models.CharField(max_length=50,null=True)

class questions(models.Model):
    staff = models.ForeignKey(Staff,on_delete=models.CASCADE)
    sub_code=models.IntegerField(null=True)
    date=models.DateField(null=True)
    duration=models.IntegerField(null=True)
    sub_name=models.CharField(max_length=50,null=True)
    qus1=models.CharField(max_length=500,null=True)
    qus2=models.CharField(max_length=500,null=True)
    qus3=models.CharField(max_length=500,null=True)
    qus4=models.CharField(max_length=500,null=True)
    qus5=models.CharField(max_length=500,null=True)
    qus6=models.CharField(max_length=500,null=True)
    qus7=models.CharField(max_length=500,null=True)
    qus8=models.CharField(max_length=500,null=True)
    qus9=models.CharField(max_length=500,null=True)
    qus10=models.CharField(max_length=500,null=True)
    key1=models.CharField(max_length=500,null=True)
    key2=models.CharField(max_length=500,null=True)
    key3=models.CharField(max_length=500,null=True)
    key4=models.CharField(max_length=500,null=True)
    key5=models.CharField(max_length=500,null=True)
    key6=models.CharField(max_length=500,null=True)
    key7=models.CharField(max_length=500,null=True)
    key8=models.CharField(max_length=500,null=True)
    key9=models.CharField(max_length=500,null=True)
    key10=models.CharField(max_length=500,null=True)

    def is_active(self):
        if self.date == datetime.date.today():
            return True
        else:
            return False
        

class ans_pdf(models.Model):
    student=models.ForeignKey(student,on_delete=models.CASCADE)
    question=models.ForeignKey(questions,on_delete=models.CASCADE)
    pdf=models.FilePathField(null=True)
    mark=models.IntegerField(null=True)
    starting_time = models.TimeField()
    end_time = models.TimeField()
    is_attended = models.BooleanField(default=False)
    is_expired = models.BooleanField(default=False)
    is_uploaded = models.BooleanField(default=False)