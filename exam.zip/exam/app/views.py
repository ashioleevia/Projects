from difflib import SequenceMatcher
from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User,auth
from fpdf import FPDF
from django.http import FileResponse
import os
import tabula
from datetime import datetime, timedelta
import cv2
import mediapipe as mp
import numpy as np
import time

mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(min_detection_confidence=0.5, min_tracking_confidence=0.5)

mp_drawing = mp.solutions.drawing_utils

drawing_spec = mp_drawing.DrawingSpec(thickness=1, circle_radius=1)


cap = cv2.VideoCapture(0)



def index(request):
    return render(request,'index.html')
def facualtylog(request):
    #global s
    if request.method=='POST':
        staff_id=request.POST['staff_id']
        staff_pass=request.POST['staff_pass']
        if Staff.objects.filter(staff_id=staff_id,password=staff_pass).exists():
            #s=Staff.objects.filter(staff_id=staff_id,password=staff_pass)
            u=auth.authenticate(username=staff_id,password=staff_pass)
            if u is not None:
                auth.login(request,u)
                #s=Staff.objects.get(staff_id=staff_id,password=staff_pass)
                print(staff_id)
                return redirect(staffmain)
                #return render(request,'staffmain.html',{'key':s})
        else:
            return render(request,'facualty_login.html',{'key':'invalid user'})
    return render(request,'facualty_login.html')
def facualtyreg(request):
    if request.method=='POST':
        s_name=request.POST['staff_name']
        s_id=request.POST['staff_id']
        s_dep=request.POST['department']
        s_pass=request.POST['Password']
        s_cpass=request.POST['con_password']
        if s_pass==s_cpass:
            user = None
            if User.objects.filter(username=s_id).exists():
                user=User.objects.get(username=s_id)
                if Staff.objects.filter (user=user).exists():
                    return render(request,'facualty_registration.html',{'key':'staff id already exists'})
            else:
                User.objects.create_user(username=s_id, password=s_pass,first_name=s_name).save()
                user=User.objects.get(username=s_id)
            if user:
                if Staff.objects.filter (staff_id=s_id).exists():
                    return render (request, 'facualty_registration.html',{'key': 'staff id already exists'})
                else:
                    Staff(user=user, staff_name=s_name,staff_id=s_id, department=s_dep,password=s_pass).save()
                    return render (request, 'facualty_registration.html',{'key':'registered sucessfully'})
        else:
            return render(request,'facualty_registration.html',{'key':'password does not mathch'})

    return render(request,'facualty_registration.html')


def studentlog(request):
    if request.method=='POST':
        stud_id=request.POST['stud_roll']
        stud_pass=request.POST['stud_pass']
        if student.objects.filter(student_id=stud_id,student_password=stud_pass).exists():
            u=auth.authenticate(username=stud_id,password=stud_pass)
            if u is not None:
                auth.login(request,u)
                return redirect(student_main)
                #return redirect(studentindex)
        else:
            return render(request,'student_login.html',{'key':'invalid user'})
    return render(request,'student_login.html')

def studentreg(request):
    if request.method=='POST':
        stud_name=request.POST['stud_name']
        stud_id=request.POST['stud_id']
        stud_dep=request.POST['department']
        stud_pass=request.POST['Password']
        stud_cpass=request.POST['con_password']
        if stud_pass==stud_cpass:
            user = None
            if User.objects.filter(username=stud_id).exists():
                user=User.objects.get(username=stud_id)
                if Staff.objects.filter (user=user).exists():
                    return render(request,'student_registration.html',{'key':'staff id already exists'})
            else:
                User.objects.create_user(username=stud_id, password=stud_pass,first_name=stud_name).save()
                user=User.objects.get(username=stud_id)
            if user:
                if student.objects.filter (student_id=stud_id).exists():
                    return render (request, 'student_registration.html',{'key': 'staff id already exists'})
                else:
                    student(user=user, student_name=stud_name,student_id=stud_id,student_department=stud_dep,student_password=stud_pass).save()
                    return render (request, 'student_registration.html',{'key':'registered sucessfully'})
        else:
            return render(request,'student_registration.html',{'key':'password does not mathch'})


    return render(request,'student_registration.html')

def staff_question_view(request):
    qus=questions.objects.filter(staff__user=request.user)

    return render(request,'staff_question_view.html',{'key':qus})
def staff_view_details(request,pk):
    qus=questions.objects.get(id=pk)
    return render(request,'staff_view_details.html',{'key':qus})
def staff_delete_qustions(request,pk):
    qus=questions.objects.get(id=pk)
    qus.delete()
    return redirect(staff_question_view)

def examquestions(request):
    staff = Staff.objects.get(user=request.user)
    if request.method=='POST':
        sub_name=request.POST['sub_name']
        sub_code=request.POST['sub_code']
        date=request.POST['date']
        duration=request.POST['duration']

        qus1=request.POST['qus1']
        qus2=request.POST['qus2']
        qus3=request.POST['qus3']
        qus4=request.POST['qus4']
        qus5=request.POST['qus5']
        qus6=request.POST['qus6']
        qus7=request.POST['qus7']
        qus8=request.POST['qus8']
        qus9=request.POST['qus9']
        qus10=request.POST['qus10']
        key1=request.POST['key1']
        key2=request.POST['key2']
        key3=request.POST['key3']
        key4=request.POST['key4']
        key5=request.POST['key5']
        key6=request.POST['key6']
        key7=request.POST['key7']
        key8=request.POST['key8']
        key9=request.POST['key9']
        key10=request.POST['key10']
        
        questions(staff=staff,sub_code=sub_code,date=date,duration=duration,sub_name=sub_name,qus1=qus1,qus2=qus2,qus3=qus3,qus4=qus4,qus5=qus5,qus6=qus6,qus7=qus7,qus8=qus8,qus9=qus9,qus10=qus10,key1=key1,key2=key2,key3=key3,key4=key4,key5=key5,key6=key6,key7=key7,key8=key8,key9=key9,key10=key10).save()
        return redirect(staffmain)
    #print(staff_id)
    context = {'staff' : staff}
    return render(request,'exam_qustions.html',context)

def staffmain(request):
    
    return render(request,'staffmain.html')
def student_main(request):
    
    return render(request,'student_main.html')

def studexamview(request):
    student_obj = student.objects.get(user=request.user)
    attended_questions = ans_pdf.objects.filter(is_expired=True,student=student_obj).values_list('question__pk')
    exams=questions.objects.filter(staff__department__iexact=student_obj.student_department).exclude(pk__in=attended_questions)
    return render(request,'studexamview.html',{'key':exams})





def attend_exam(request,pk):
    exams=questions.objects.get(id=pk)
    user=User.objects.get(username=request.user)
    users=student.objects.get(user=user)
    student_obj = student.objects.get(user=request.user)
    if request.method=='POST':
        is_expired = False
        if ans_pdf.objects.filter(student=student_obj,question=exams,is_attended=True,is_expired=False,is_uploaded=False).exists():
            exam = ans_pdf.objects.filter(student=student_obj,question=exams,is_attended=True,is_expired=False,is_uploaded=False).latest('id')
            if exam.end_time < datetime.now().time():
                is_expired = True
            else:
                is_expired = False
        else:
            is_expired = False
        if not is_expired :
            ans1=request.POST['ans1']
            ans2=request.POST['ans2']
            ans3=request.POST['ans3']
            ans4=request.POST['ans4']
            ans5=request.POST['ans5']
            ans6=request.POST['ans6']
            ans7=request.POST['ans7']
            ans8=request.POST['ans8']
            ans9=request.POST['ans9']
            ans10=request.POST['ans10']
            data = (
            (" "," "),
            ("question","answer"),
            (exams.qus1, ans1),
            (exams.qus2, ans2),
            (exams.qus3, ans3),
            (exams.qus4, ans4),
            (exams.qus5, ans5),
            (exams.qus6, ans6),
            (exams.qus7, ans7),
            (exams.qus8, ans8),
            (exams.qus9, ans9),
            (exams.qus10, ans10),
            
            )



            pdf = FPDF()
            pdf.add_page()
                    
            pdf.set_font("Times", size=10)

            #pdf.cell(200, 10, txt = exams.sub_code,align = 'C')
            pdf.cell(200, 10, txt = "Answersheet",align='C')
            


            line_height = pdf.font_size * 2.5
            col_width = pdf.epw / 2  


            for row in data:
                
                for datum in row:
                    pdf.multi_cell(col_width, line_height, datum, border=1,
                            new_x="RIGHT", new_y="TOP", max_line_height=pdf.font_size)
                pdf.ln(line_height)
            pdf.output('static/'+student_obj.student_name+student_obj.student_department+str(exams.sub_code)+'.pdf')
            # pdf=FPDF('P','mm','Letter')
            # pdf.add_page()
            # pdf.set_font('helvetica','B',22)

            # pdf.cell(0,10,'hello world',align='C')
            # pdf.output('pdfpart.pdf')
            
            # filepath = os.path.join('', 'pdfpart.pdf')
            filepath=os.path.join('static',student_obj.student_name+student_obj.student_department+str(exams.sub_code)+'.pdf')
            answer = ans_pdf.objects.get(student=student_obj,question=exams,is_attended=True)
            answer.pdf=filepath
            answer.is_uploaded = True
            answer.is_expired = True
            answer.save()
            context={
                'key':exams,
                'key1':'sumbited succesfully'

            }
            return render(request,'attendexam.html',context)
        else:
            exam.is_expired=True
            exam.save()
            context={
                'error':"Exam submission expired!",
            }
            return render(request,'error.html',context)

        # return FileResponse(open(filepath, 'rb'), content_type='application/pdf')
    else:
        if not ans_pdf.objects.filter(student=student_obj,question=exams,is_attended=True,is_uploaded=True,is_expired=True).exists():
            start_time = datetime.now().time()
            end_time = (datetime.now()+ timedelta(hours=1)).time()
            ans_pdf(student=student_obj,question=exams,is_attended=True,starting_time=start_time,end_time=end_time).save()
            os.system("start /B start cmd.exe @cmd /c py test.py")
            return render(request,'attendexam.html',{'key':exams})
        else:
            context={
                'error':"Already attended the Exam!",
            }
            return render(request,'error.html',context)

def studviewattendedexam(request):
    
    student_obj = student.objects.get(user=request.user)
    ansview=ans_pdf.objects.filter(student=student_obj)
    
    print('hlo')
    print(student_obj.student_id)
    #print(ansview.)
    context={'key':ansview}
    
    return render(request,'studviewattededexam.html',context)

def show_pdf(request,pk):
    filepath = ans_pdf.objects.get(id=pk).pdf
    return FileResponse(open(filepath, 'rb'), content_type='application/pdf')

def exam_attended(request):
    
    staff = Staff.objects.get(user=request.user)
    ansview=ans_pdf.objects.filter(question__staff=staff)
    
    #print(ansview.)
    context={'key':ansview}
    
    return render(request,'exam_attended.html',context)


def e_val(request,pk):
    filepath = ans_pdf.objects.get(id=pk).pdf
    filepath2 = ans_pdf.objects.get(id=pk)

    print(filepath)
    print(filepath2.question.key1)
    anskey=[filepath2.question.key1,filepath2.question.key2,filepath2.question.key3,filepath2.question.key4,filepath2.question.key5,filepath2.question.key6,filepath2.question.key7,filepath2.question.key8,filepath2.question.key9,filepath2.question.key10]
    
    dfs = tabula.read_pdf(filepath, stream=True)
    # read_pdf returns list of DataFrames

    # print(len(dfs))
    # print(dfs[0]['answer'])
    my_ans=dfs[0]['answer'].values.tolist()

    final=list(zip(anskey, my_ans))

    sh=[]

    for i in final:
        r=anserkey(i[0],i[1])
        sh.append(r)

    print(sh)
    result=sum(sh)/10

    print(result)

    filepath2.mark=result
    filepath2.save()
    filepath2 = ans_pdf.objects.get(id=pk)

    return render(request,'eval.html',{'key':filepath2})


def anserkey(a1,b1):


    string1 = a1
    string2 = b1

  
    match = SequenceMatcher(None,
                            string1, string2)

   
    result = match.ratio() * 100

    return (int(result))
