from django.urls import path
from . import views

urlpatterns = [
    path('',views.index),
    path('facualtylog',views.facualtylog),
    path('facualtyreg',views.facualtyreg),
    path('studentlog',views.studentlog),
    path('studentreg',views.studentreg),
    path('staff_question_view',views.staff_question_view),
    path('examqus',views.examquestions),
    path('staffmain',views.staffmain),
    path('staff_view_details<str:pk>',views.staff_view_details,name='staff_view_details'),
    path('staff_delete_qustions<str:pk>',views.staff_delete_qustions,name='staff_delete_qustions'),
    path('studentmain',views.student_main),
    path('studexamview',views.studexamview),
    path('attend_exam<str:pk>',views.attend_exam,name='attend_exam'),
    path('studviewattendedexam',views.studviewattendedexam),
    path('show_pdf<int:pk>',views.show_pdf,name='show_pdf'),
    path('exam_attended',views.exam_attended),
    path('evals<str:pk>',views.e_val,name='eval'),



]